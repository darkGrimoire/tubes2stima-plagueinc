# Tugas Besar STIMA #2: Plague Inc
Anggota:  
- Ignatius David Partogi (13518014)  
- Rafael Sean Putra (13518119)  
- Faris Rizki Ekananda (13518125)  

## Requirements
- .NET Framework versi terbaru
- Visual Studio (untuk build)

## Cara Build
### Windows dan Linux
1. Buka folder `src`
2. Buka buka csproj dengan Visual Studio
3. Pilih `start` pada toolbar di atas. Pastikan targetnya adalah `Release`

## Cara Run
### Windows dan Linux
1. Buka folder `bin`
2. jalankan file berekstensi `.exe`